function forword(){
	setInterval("a()",1000);
}
function a(){
		var path = document.getElementById("path").innerHTML;
		var times = document.getElementById("msg");
		var time = times.innerHTML;
		times.innerHTML = time-1;
		if(time == 1){
			location = path;
		}
}