create table t_msg(
    id int auto_increment,
    username varchar(20),
    title varchar(15),
    email varchar(18),
    address varchar(5),
    phtot int ,
    iqcq varchar(20),
    mypage varchar(30),
    content text,
    Mdate date,
    state int,#管理员设置 默认为0为未审核，为1则审核成功
 primary key(id)
);
drop table msg;
create table t_users(
   ud int auto_increment,
   username varchar(20),
   passwords varchar(20),
 primary key(ud)
);
insert into t_users values(null,'admin','12345'); 
select * from t_user;
select * from msg1;