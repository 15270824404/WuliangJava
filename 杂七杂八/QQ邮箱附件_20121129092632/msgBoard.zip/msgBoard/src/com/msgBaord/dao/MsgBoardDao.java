package com.msgBaord.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.msgBaord.pojo.Msg;
import com.msgBaord.util.DBUtil;


public class MsgBoardDao {
	public static void saveDao(Msg msg){
  	  Connection conn = DBUtil.getConn();
  	  PreparedStatement pstmt = DBUtil.getPstmt(conn,"insert into t_msg values(null,?,?,?,?,?,?,?,?,now(),0)");
  	  try {
  		  pstmt.setString(1,msg.getUsername());
  		  pstmt.setString(2,msg.getTitle());
  		  pstmt.setString(3,msg.getEmail());
  		  pstmt.setString(4,msg.getAddress());
  		  pstmt.setInt(5,msg.getPhtot());
  		  pstmt.setString(6,msg.getIqcq());
  		  pstmt.setString(7,msg.getMypage());
  		  pstmt.setString(8,msg.getContent());
  		  pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
		   DBUtil.getClose(conn, pstmt, null);	
		}    	  
    }
    public static List<Msg> getDao(HttpServletRequest request, HttpServletResponse response){
  	  List<Msg>  msgs = new ArrayList<Msg>();
  	  Connection conn = DBUtil.getConn();
  	PreparedStatement pstmt = null;
  	  if(request.getSession().getAttribute("login") != null){
  		pstmt = DBUtil.getPstmt(conn,"select * from t_msg");
  	  }else{
  		pstmt = DBUtil.getPstmt(conn,"select * from t_msg where state=1");
  	  }
  	  ResultSet rs = DBUtil.getRs(pstmt);
  	  try {
			while(rs.next()){
				Msg msg = new Msg();
				msg.setId(rs.getInt(1));
				msg.setUsername(rs.getString(2));
				msg.setTitle(rs.getString(3));
				msg.setEmail(rs.getString(4));				
				msg.setAddress(rs.getString(5));
				msg.setPhtot(rs.getInt(6));
				msg.setIqcq(rs.getString(7));
				msg.setMypage(rs.getString(8));
				msg.setContent(rs.getString(9));
				msg.setMdate(rs.getTimestamp(10));
				msg.setState(rs.getInt(11));
				msgs.add(msg);
			  }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstmt, rs);
		}
  	  return msgs;
    }
    public static List<Msg> updateMsg(int id,int state){
    	  List<Msg>  msgs = new ArrayList<Msg>();
    	  Connection conn = DBUtil.getConn();
    	  PreparedStatement pstmt = null;
    	  if(state == 0){
    		  pstmt = DBUtil.getPstmt(conn,"update t_msg set state=1,content='未通过审核'  where id=?");
    	  }else{
    		  pstmt = DBUtil.getPstmt(conn,"update t_msg set state=1 where id=?");
    	  }
    	  try {
    		  pstmt.setInt(1, id);
  			  pstmt.executeUpdate();
  		} catch (SQLException e) {
  			// TODO Auto-generated catch block
  			e.printStackTrace();
  		}finally{
  			DBUtil.getClose(conn, pstmt, null);
  		}
    	  return msgs;
      }
    public static void deleteDao(int id){
  	  Connection conn = DBUtil.getConn();
  	  PreparedStatement pstmt = DBUtil.getPstmt(conn,"delete from t_msg where id=?");
  	  try {
  		pstmt.setInt(1, id);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstmt, null);
		}
    }
}
