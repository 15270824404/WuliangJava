package com.msgBaord.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.msgBaord.exception.PasswordErrorEcxeption;
import com.msgBaord.exception.UsernameNotFormException;
import com.msgBaord.util.DBUtil;


public class UserDao {
	      public static void setUser(String username,String passwords){
	    	  Connection conn = DBUtil.getConn();
	    	  PreparedStatement pstmt = DBUtil.getPstmt(conn, "select passwords from t_users where username=?");
	    	  ResultSet rs =null;
	    	  try {
				pstmt.setString(1,username);
				rs = DBUtil.getRs(pstmt);
				if(rs.next()){
					if(!passwords.equals(rs.getString(1))){
						throw new PasswordErrorEcxeption();
					}
				}else{
					throw new UsernameNotFormException();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				DBUtil.getClose(conn, pstmt, null);
			}
	      }
	}

