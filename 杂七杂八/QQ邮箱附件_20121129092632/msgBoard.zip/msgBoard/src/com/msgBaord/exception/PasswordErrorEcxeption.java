package com.msgBaord.exception;

public class PasswordErrorEcxeption extends RuntimeException {

}
