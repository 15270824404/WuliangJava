package com.msgBaord.exception;

public class UsernameNotFormException extends RuntimeException {

}
