package com.msgBaord.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBUtil {
	 private DBUtil(){}
	 static {
		 try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("数据库连接失败");
		}
	 }
	 public static Connection getConn(){
		 Connection conn = null;
		 try {
			conn = DriverManager.getConnection("jdbc:mysql:///test","root","root");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	 }
	 public static PreparedStatement getPstmt(Connection conn,String sql){
		 PreparedStatement pstmt = null;
		
			try {
				pstmt = conn.prepareStatement(sql);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return pstmt;
	 }
	 public static ResultSet getRs(PreparedStatement pstmt){
		 ResultSet rs = null;
		 try {
			rs = pstmt.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return rs;
	 }
	 public static void getClose(Connection conn,PreparedStatement pstmt,ResultSet rs){
		 if(rs != null){
			 try {
				rs.close();
				 rs = null;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		 }
		 if(pstmt != null){
			 try {
				 pstmt.close();
				 pstmt = null;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		 }
		 if(conn != null){
			 try {
				 conn.close();
				 conn = null;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		 }
	 }	 
}
