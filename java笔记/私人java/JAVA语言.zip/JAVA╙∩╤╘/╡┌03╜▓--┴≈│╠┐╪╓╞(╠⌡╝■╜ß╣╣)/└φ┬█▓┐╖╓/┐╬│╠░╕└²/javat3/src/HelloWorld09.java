/**
 * HelloWorld9.java  ��ʾswitch�ṹ
 */
public class HelloWorld09 {
    public static void main(String[] args) {
        int mingCi = 1;  //����
        switch (mingCi){
            case 1:
            	System.out.println("���ΰ೤");
                break;
            case 2:
            	System.out.println("���δ�ӳ�");
                break;
            case 3:
            	System.out.println("����С�鳤");
                break;
            default:
            	System.out.println("����");
            	break;
        }
    }
}
