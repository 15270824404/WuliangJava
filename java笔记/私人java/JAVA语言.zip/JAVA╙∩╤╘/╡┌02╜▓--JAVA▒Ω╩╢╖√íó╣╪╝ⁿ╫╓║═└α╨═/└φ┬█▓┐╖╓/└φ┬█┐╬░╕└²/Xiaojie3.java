public class Xiaojie3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		double r = 4.5;
		double pi = 3.14159;
		int area = (int) (pi * r * r);
		System.out.print("�뾶Ϊ��" + r + "��Բ������ǣ�" + area);

	}

}
