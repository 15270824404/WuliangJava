package kehou.zuoye1;

public class Test {
	public static void main(String[] args) {
		new PrintJiShu().start();
		new PrintOuShu().start();
	}
}
