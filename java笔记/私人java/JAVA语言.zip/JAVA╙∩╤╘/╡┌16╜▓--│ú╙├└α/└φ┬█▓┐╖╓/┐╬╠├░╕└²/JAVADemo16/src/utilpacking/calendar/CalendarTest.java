package utilpacking.calendar;

import java.util.Calendar;

public class CalendarTest {
	public static void main(String[] args) {
		Calendar rightNow = Calendar.getInstance();
		System.out.println("��ǰʱ�䣺" + rightNow.getTime());
	}
}
