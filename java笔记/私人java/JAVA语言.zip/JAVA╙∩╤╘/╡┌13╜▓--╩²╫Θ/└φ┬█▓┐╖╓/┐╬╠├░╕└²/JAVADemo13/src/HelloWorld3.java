

public class HelloWorld3 {
	public static void main(String[] args) {
		int[] score = new int[2];
		score[0] = 89;
		score[1] = 63;
		score[2] = 45;
		System.out.println(score[2]);
	}
}
