

public class HelloWorld4 {
	public static void main(String[] args) {
		int[] score = new int[3];
		score[0] = 89;
		System.out.println(score[1]);
	}
}
