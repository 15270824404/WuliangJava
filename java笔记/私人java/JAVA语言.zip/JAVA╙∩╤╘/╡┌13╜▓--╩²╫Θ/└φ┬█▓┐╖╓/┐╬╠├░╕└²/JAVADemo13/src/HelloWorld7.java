

public class HelloWorld7 {
	public static void main(String[ ] args){
	       int[ ] score = new int[5];
	       score = {60, 80, 90, 70, 85};
	      
	       int[ ] score2;
	       score2 = {60, 80, 90, 70, 85}; 
	} 

}
