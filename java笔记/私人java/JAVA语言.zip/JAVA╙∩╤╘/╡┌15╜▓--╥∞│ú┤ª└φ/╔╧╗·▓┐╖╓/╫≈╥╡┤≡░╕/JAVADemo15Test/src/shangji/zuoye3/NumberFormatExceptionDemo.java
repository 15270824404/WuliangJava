package shangji.zuoye3;

public class NumberFormatExceptionDemo {
	public static void main(String args[]) {
		String stuName = " tom";
		int result = Integer.parseInt(stuName);
	}
}
