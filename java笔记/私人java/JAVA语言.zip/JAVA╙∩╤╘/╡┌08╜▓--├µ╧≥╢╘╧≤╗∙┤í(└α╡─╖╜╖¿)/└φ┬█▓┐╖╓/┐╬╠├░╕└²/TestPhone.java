/*
 * TestPhone.java  �����ֻ���
 */
public class TestPhone {
	public static void main(String[] args) {
		Phone phone = new Phone();
		phone.playMusic();
		phone.chargeCell();
	}
}
