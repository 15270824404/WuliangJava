public class VariableDomain1 {
	public static void main(String[] args) {
		for (int i = 0, a = 0; i < 4; i++) {
			a++;
		}
		System.out.println(a);
	}
}
