package list;

public class Student {
	public String toString(){
		return "Student�����";
	}
}
