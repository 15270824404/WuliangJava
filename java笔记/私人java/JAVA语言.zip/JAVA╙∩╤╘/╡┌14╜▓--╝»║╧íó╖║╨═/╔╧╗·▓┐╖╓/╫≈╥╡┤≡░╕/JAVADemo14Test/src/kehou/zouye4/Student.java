package kehou.zouye4;

public class Student {

	private String stuName;
	private int age;

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public void setAge(int age) {
		this.age = age;

	}

	public String getStuName() {
		return this.stuName;
	}

	public int getAge() {
		return this.age;
	}

}
