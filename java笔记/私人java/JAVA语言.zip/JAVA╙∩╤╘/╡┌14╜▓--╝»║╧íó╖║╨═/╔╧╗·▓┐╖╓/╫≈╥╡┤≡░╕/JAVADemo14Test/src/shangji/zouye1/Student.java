package shangji.zouye1;

public class Student {
	public String toString(){
		return "Student�����";
	}
}
