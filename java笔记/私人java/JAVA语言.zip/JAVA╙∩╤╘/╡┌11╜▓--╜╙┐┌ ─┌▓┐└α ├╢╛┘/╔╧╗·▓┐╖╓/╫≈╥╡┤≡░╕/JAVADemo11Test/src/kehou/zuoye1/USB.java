package kehou.zuoye1;
/*
 * ģ��USB�ӿ�
 */
public interface USB {
	public void start();
	public void stop();
}
